<!doctype html>
<html>
<head>
	<title>Mad Lips</title>
	<link href="style.css" rel="stylesheet" type="text/css" />	
</head>
<body>
<div class="logo">Mad Lips</div>
<div class="body">
<div class="menu">
	<ul>
		<li><a href="index.php">Er heerst paniek...</a></li>
		<li><a href="onkunde.php">Onkunde</a></li>
	</ul>

</div>
<div class="text">	
<h2>Er heerst paniek...</h2>
<form action="welcome.php" method="post">
<p>Welk dier zou je nooit als huisdier willen hebben?<input type="text" name="1"></p>
<p>Wie is de belangrijkste persoon in je leven?<input type="text" name="2"></p></p>
<p>In welk land zou je graag willen wonen?<input type="text" name="3"></p></p>
<p>Wat doe je als je je verveelt?<input type="text" name="4"></p></p>
<p>Met welk speelgoed speelde je als kind het meest?<input type="text" name="5"></p></p>
<p>Bij welke docent spijbel je het liefst?<input type="text" name="6"></p></p>
<p>Als je EUR 100.000,- had, wat zou je dan kopen?<input type="text" name="7"></p></p>
<p>Wat is je favoriete bezigheid?<input type="text" name="8"></p></p>
<input type="submit">
</form>

</div>
<div class="under">Deze website is gemaakt door Dilie</div>
</div>
</body>
</html>