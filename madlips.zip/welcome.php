<!doctype html>
<html>
<head>
	<title>Mad Lips</title>
	<link href="style.css" rel="stylesheet" type="text/css" />	
</head>
<body>
<div class="logo">Mad Lips</div>
<div class="body">
<div class="menu">
	<ul>
		<li><a href="index.php">Er heerst paniek...</a></li>
		<li><a href="onkunde.php">Onkunde</a></li>
	</ul>

</div>
<div class="text">	
<h2>Er heerst paniek...</h2>
<p>Er heerst paniek in het koninkrijk <?php echo $_POST["3"]; ?>.
Koning <?php echo $_POST["2"]; ?> is ten einde raad en als koning <?php echo $_POST["2"]; ?> ten einde raad is, dan roept hij zijn ten-einde-raadsheer <?php echo $_POST["6"]; ?>.</p>

<p><?php echo $_POST["6"]; ?>! Het is een ramp! Het is een schande!"  </p>
<p>"Sire, Majesteit, Uwe Luidruchtigheid, wat is er aan de hand?"</p>
<p>"Mijn <?php echo $_POST["1"]; ?>is verdwenen! Zo maar, zonder waarschuwing. 
En ik had net  <?php echo $_POST["5"]; ?> voor hem gekocht!"</p>
<p>"Majesteit, uw <?php echo $_POST["1"]; ?> komt vast vanzelf weer terug?"</p>
<p>"Ja, da's leuk en aardig, maar hoe moet ik in de tussentijd <?php echo $_POST["8"]; ?> leren?"</p>
<p>"Maar Sire, daar kunt u toch uw <?php echo $_POST["7"]; ?> voor gebruiken."</p>
<p>"<?php echo $_POST["6"]; ?>, je hebt helemaal gelijk! Wat zou ik doen als ik jou niet had."</p>
<p>"<?php echo $_POST["4"]; ?>, Sire."</p>

</div>
<div class="under">Deze website is gemaakt door Dilie</div>
</div>
</body>
</html>