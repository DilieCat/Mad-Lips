<!doctype html>
<html>
<head>
	<title>Mad Lips</title>
	<link href="style.css" rel="stylesheet" type="text/css" />	
</head>
<body>
<div class="logo">Mad Lips</div>
<div class="body">
<div class="menu">
	<ul>
		<li><a href="index.php">Er heerst paniek...</a></li>
		<li><a href="onkunde.php">Onkunde</a></li>
	</ul>

</div>
<div class="text">	
<h2>Onkunde</h2>
<form action="welcome2.php" method="post">
<p>Wat zou je graag willen kunnen?<input type="text" name="1"></p>
<p>Met welke persoon kun je goed opschieten?<input type="text" name="2"></p>
<p>Wat is je favoriete getal?<input type="text" name="3"></p>
<p>Wat heb je altijd bij je als je op vakantie gaat?<input type="text" name="4"></p>
<p>Wat is je beste persoonlijke eigenschap?<input type="text" name="5"></p>
<p>Wat is je slechtste persoonlijke eigenschap?<input type="text" name="6"></p>
<p>Wat is het ergste dat je kan overkomen?<input type="text" name="7"></p>
<input type="submit">
</form>

</div>
<div class="under">Deze website is gemaakt door Dilie</div>
</div>
</body>
</html>