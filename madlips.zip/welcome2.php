<!doctype html>
<html>
<head>
	<title>Mad Lips</title>
	<link href="style.css" rel="stylesheet" type="text/css" />	
</head>
<body>
<div class="logo">Mad Lips</div>
<div class="body">
<div class="menu">
	<ul>
		<li><a href="index.php">Er heerst paniek...</a></li>
		<li><a href="onkunde.php">Onkunde</a></li>
	</ul>

</div>
<div class="text">	
<h2>Onkunde</h2>
Er zijn veel mensen die niet kunnen <?php echo $_POST["1"]; ?>. Neem nou <?php echo $_POST["2"]; ?>. 
Zelfs met de hulp van een <?php echo $_POST["4"]; ?> of zelfs <?php echo $_POST["3"]; ?> kan <?php echo $_POST["2"]; ?> niet <?php echo $_POST["1"]; ?>. 
Dat heeft niet te maken met een gebrek aan <?php echo $_POST["5"]; ?>, maar met een te veel aan <?php echo $_POST["6"]; ?>. 
Te veel <?php echo $_POST["6"]; ?> leidt tot <?php echo $_POST["7"]; ?> en dat is niet goed als je wilt <?php echo $_POST["1"]; ?>. 
Helaas voor <?php echo $_POST["2"]; ?>.

</div>
<div class="under">Deze website is gemaakt door Dilie</div>
</div>
</body>
</html>